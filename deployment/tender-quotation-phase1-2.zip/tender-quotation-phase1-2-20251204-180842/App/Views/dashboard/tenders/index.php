<?php
global $context;
$data = $context->data;
$crumbs = getCrumbs();

?>

<div class="row">
    <h1>
        Tenders
    </h1>

    <div class="col-12 col-md-12 order-md-2 order-first">
        <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
            <ol class="breadcrumb">
             
        <?php
        
        foreach ($crumbs as $key => $crumb) 
        {
            if($key == (count($crumbs)-1))
            {
                $active = 'active';
       echo ' <li class="breadcrumb-item '.$active.'" aria-current="page">'.$crumb.'</li>  ';
            }else{   
                $active = '';
          echo '<li class="breadcrumb-item '.$active.'" aria-current="page">'.$crumb.'</li>';
            }
        }
        ?>
        

        </ol>
        </nav>
    </div>
</div>

<div class="row">
    <div class="col-md">
        <div class="card">
            <div class="card-header">
                <p class="card-title fs-5">Tender List</p>
                <div class="float-start float-lg-end">
                    <a class="btn btn-sm" href="<?php echo buildurl("dashboard/tenders/add") ?>" role="button">
                        <i class="bi bi-plus"></i> Add
                    </a>
                    <button class="btn  btn-sm" onclick="handleDownload()">
                        <i class="bi bi-download"></i> Save
                    </button>
                    <a class="btn btn-warning btn-sm" href="<?php echo buildurl("dashboard/tenders/archiveExpired") ?>" role="button" onclick="return confirm('Archive all expired tenders? This will update their status to Archived.')">
                        <i class="bi bi-archive"></i> Archive Expired
                    </a>
                </div>
            </div>
            <div class="card-content">
            <?php include ('Includes/parts/alerts.php') ?>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-lg" id="table1">
                            <thead>
                                <tr>
                                    <th>NO#</th>
                                    <th>TITLE</th>
                                    <th>SUMMARY</th>
                                    <th>BODY</th>
                                    <th>POSTED BY</th>
                                    <th>CREATED DATE</th>
                                    <th>STATUS</th>
                                    <th>ACTIONS</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach ($data as $key => $service) {
                                    $key++;

                                    switch ($service['status']) {
                                        case '1':
                                     $status =  '<span class="badge bg-light-primary">Current</span>';
                                            break;
                                        case '2':
                                            $status =  '<span class="badge bg-light-success">Open</span>';
                                            break;
                                        case '3':
                                            $status = '<span class="badge bg-light-secondary">Awarded</span>';
                                            break;

                                        default:
                                        $status =  '<span class="badge bg-light-danger">Closed</span>';
                                            break;
                                    }


                                    echo '
                                <tr>
                                    <td class="text-bold-500">' . $key . '</td>
                                    <td>' . $service['title'] . '</td>
                                    <td>' . $service['subtitle'] . '</td>
                                    <td>' .strip_tags( $service['body']) . '</td>
                                    <td class="text-bold-500">' . $service['updatedBy'] . '</td>
                                    <td class="text-bold-500">' .formatDate( $service['createdAt']) . '</td>
                                    <td> 
                                        '.$status.'
                                    </td>
                                    <td>
                                       
                                        <a class="btn  btn-sm p-2" href="add?id=' .  $service['id'] . '" style="position: absolute;
  display: contents;">
                                        <i class="bi bi-pencil"></i>
                                        </a>
                                        <a class="btn btn-sm p-2" href="delete?id='.  $service['id'] .'"onclick="handleDelete(event, '.$service['id'].')" style="position: absolute;
  display: contents;">
                                         <i class="bi bi-trash"></i>
                                    </a>
                                    </td>
                                </tr>';
                                }
                                ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
